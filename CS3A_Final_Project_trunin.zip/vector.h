#ifndef VECTOR_H
#define VECTOR_H

#include <iostream>
#include "../../../!includes/one_d/oned_library.h"

using namespace std;

template <typename T>
class Vector{
public:

    Vector(unsigned int init_cap = 10);  //ctor

    // big three:
    Vector ( const Vector& other );
    Vector& operator=(const Vector& other);
    ~Vector();

    //member access functions:
    const T operator []( unsigned int index) const;
    T& operator []( unsigned int index);
    T& at(int index);             //return reference to item at position index
    const T at(int index) const;  //return a const item at position index
    T& front() const;             //return item at position 0.
    T& back() const;              //return item at the last position


    //Push and Pop functions:
    Vector& operator +=(const T& item); //push_back
    void push_back (const T& item);      //append to the end
    T pop_back();                       //remove last item and return it


    //Insert and Erase:
    void insert( int insert_here, const T& insert_this); //insert at pos
    void erase(int erase_index);        //erase item at position
    int index_of(const T& item);        //search for item. retur index.

    //size and capacity:
    void set_size(int size);            //enlarge the vector to this size
    void set_capacity(int capacity);    //allocate this space
    int size() const;                   //return _size
    int capacity() const;               //return _capacity

    bool empty() const;                 //return true if vector is empty

    //error handling routines
    int error() const;      //return error state
    int check_error(int index = 0);
    //checks for error cond and returns error code
    string error_description() const;
    //return a descriptive error message

    //OUTPUT:
    template <typename U>
    friend ostream& operator <<(ostream& outs, const Vector<U>& _a);
private:
    T* _v;
    int _size;
    int _capacity;
    int _error;
};

//============================================================================

template<typename T>
Vector<T> :: Vector(unsigned int init_cap )  //ctor, set the initial capacity
{
    _size = 0;
    set_size(_size);
    _error = 0;
    set_capacity(init_cap);
}

//----------------BIG3---------------------
template<typename T>
Vector<T> :: Vector ( const Vector& other )
{
    //3. allocate space for new string
    _v = new T[other._size + 1];
    //4. copy everything over
    copy_list(_v, other._v, other._size);
    _size = other._size;
    _capacity = other._capacity;
    _error = other._error;
}

template<typename T>
Vector<T>& Vector<T> :: operator=(const Vector& other)
{
    if (this == &other){  //1. check for self-reference
        return *this;
    }

    delete[] _v;          //2. dealloate existing space;

    _v = new T[other._size + 1];  //3. allocate space for new string

    //4. copy everything over
    copy_list( _v, other._v, other._size);
    _size = other._size;
    _capacity = other._capacity;
    _error = other._error;

    return *this;        //5. return this object
}

template<typename T>
Vector<T> :: ~Vector()
{
    delete [] _v;
}

template<typename T>
const T Vector<T> :: operator []( unsigned int index) const
{
    check_error(index);   //if the index is bigger than the capacity,
    if ( _error != 0 ){   //return the error description that goes with this
        return ( error_description() );   //situation
    }
    else {
        return ( at(index) );     //call at function to return an item
    }
}

template<typename T>
T& Vector<T> :: operator []( unsigned int index)
{
    //attention
    assert(index < size());
    assert(index >= 0);
    check_error(index);
    return ( at(index) );  //call at function to return the reference
}

template<typename T>
T& Vector<T> :: at(int index)    //return reference to item at position index
{
    T* walker = _v;            //declare a walker
    check_error(index);        //check error
    walker += index;           //move the walker
    return ( *walker );        //return the reference of that pointer
}

template <typename T>
const T Vector<T> :: at(int index) const
{                                //return a const item at position index
    T* walker = _v;
    check_error(index);
    walker += index;
    return ( *walker );        //reurn the item
}

template<typename T>
T& Vector<T> :: front() const             //return item at position 0.
{
    return ( _v[0] );
}

template<typename T>
T& Vector<T> :: back() const             //return item at the last position
{
    int index_of_last = _size - 1;
    return ( _v[index_of_last] );
}

template<typename T>
bool Vector<T> :: empty() const       //return true if vector is empty
{
    if ( _size == 0 ){   //the vector is empty when _size is 0
        return true;
    }
    return false;
}

template<typename T>
Vector<T>& Vector<T> :: operator +=(const T& item) //push_back
{
    push_back(item);      //call push back function to push back
    return *this;
}

template<typename T>
void Vector<T> :: push_back(const T& item)      //append to the end
{
    _v = add_entry( _v , item , _size , _capacity );
    size();             //call add enry from id library to push back
    capacity();
}

template<typename T>
T Vector<T> :: pop_back()          //remove last item and return it
{
    Vector<T> new_v(_capacity);
    //declare a new pointer with the currnt capacity
    int size = _size;       //declare size so that we can return the item
    copy_list ( new_v._v, _v, --_size ); //copy the item without the last item
    return _v[size];
}

template<typename T>      // int insert_here,
void Vector<T> :: insert( int insert_here, const T& insert_this)
{
    _v[insert_here] = insert_this;     //insert at pos
}

template<typename T>
void Vector<T> :: erase(int erase_index)        //erase item at position
{
    shift( _v, erase_index, _size);
    check_error();
}

template<typename T>
int Vector<T> :: index_of(const T& item)        //search for item. retur index
{
    T* address = find( item, _v, _size );
    int index = address - _v;
    return ( index );
}

template <typename U>
ostream& operator <<(ostream& outs, const Vector<U>& v)
{
    if ( v._error != 0 ){    //there is some error
        outs << v.error_description() << endl;
    }
    else {
        outs << "size: " << v._size << endl;   //output the current size and
        outs << "capacity: " << v._capacity << endl;  //current capacity
        outs << "[";
        for ( int i = 0 ; i < v._size ; i++ ){
                outs << v._v[i] << " ";  //output the object
            }
        outs << "]";
        outs << endl << "-----------------------------" << endl;
    }
    return outs;
}

template <typename T>
int Vector<T> :: error() const
{
    return _error;
}

template<typename T>
int Vector<T> :: check_error(int index)
{
    if ( _size < 0 ){      //size cannot be less than 0
        _error = 1;
        return _error;
    }
    else if ( index > _capacity || index < 0 ) {
        _error = 2;         //index cannot be out of the capacity
        return _error;
    }
    else {
        _error = 0;         //Otherwise, keep the original error
        return _error;
    }
}

template<typename T>
string Vector<T> :: error_description() const
{
    switch ( _error ) {          // shows the state
    case 0: return "NO ERROR";
    case 1: return "SIZE IS NEGATIVE";     //reurn a string based on the error
    case 2: return "INDEX IS OUT OF RANGE";       //state
    default: return "UNKNOWN ERROR";
    }
}

template<typename T>
void Vector<T> :: set_size(int size)      //enlarge the vector to this size
{       //if _capacity is less than size, we should increment the capacity
    if ( _capacity < size ){
        while ( _capacity < size ) {
            _capacity = _capacity * 2;
        }      //then, reallocate _v
        _v = reallocate_for_set_size ( _v , _size , _capacity );
    }
    //declare a walker points to the location thatis going to be initialized
    T* walker = _v;
    walker += _size;         //how many elements need to be initialized
    int size_to_be_init = size - _size;
    init ( walker , size_to_be_init );
    _size = size;           //change the private variable _size
}

template<typename T>
void Vector<T> :: set_capacity(int capacity)    //allocate this space
{
    _capacity = capacity;
    _v = allocate <T> (_capacity);
}

template<typename T>
int Vector<T> :: size () const   //return _size
{
    return _size;
}

template <typename T>
int Vector<T> :: capacity() const //return _capacity
{
    return _capacity;
}



#endif // VECTOR_H
