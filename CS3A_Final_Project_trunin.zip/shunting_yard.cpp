#include "shunting_yard.h"

shunting_yard::shunting_yard()
{
    //blank
}

shunting_yard :: shunting_yard( Queue<Token*> infix_q ): _infix_q(infix_q)
{
    //blank
}

Queue<Token*> shunting_yard :: postfix()
{
    while ( !_infix_q.Empty() ) {
        Token* i = _infix_q.pop();
        i->print();
        cout <<endl;
        if ( i->type0f() == NUMBER ){
            _postfix_q.push(i);

        }
        else if ( i->type0f() == VARIABLE ) { //X or any other variable
            _postfix_q.push(i);

        }
        else if ( i->type0f() == OPERATOR ) {
            if ( i->char_num() == 101 ) {  //e^
                _postfix_q.push(new Number(2.71828183));
            }
            else if ( _operator_s.empty() )
            {
                _operator_s.push(i);
            }

            else {
                if ( i->type0f() == _operator_s.front()->type0f() ){
                    if ( _operator_s.front()->Prec() > i->Prec() ) {
                        Token* j = _operator_s.pop();
                        _postfix_q.push(j);
                        if ( !_operator_s.empty() &&
                             (  j->Prec() == POWER_PREC &&
                                _operator_s.front()->Prec() == DIV_PREC ) ){
   //This one deals with the aituation that you have something like "3*X^2+X"
                            _postfix_q.push(_operator_s.pop());
                            //push the * into the queue
                        }
                    }
                    else if ( ( _operator_s.front()->Prec() == i->Prec()
                                    && i->Prec() < POWER_PREC ) ) {
                        Token* j = _operator_s.pop();
                        _postfix_q.push(j);
                    }
                }
                _operator_s.push(i);
            }
        }
        else if ( i->type0f() == LPAREN ) {
            _operator_s.push(i);
        }
        else if ( i->type0f() == RPAREN ) {
            Token* k = _operator_s.pop();
            while ( k->type0f() != LPAREN ) {
               _postfix_q.push(k);
               k = _operator_s.pop();
            }
        }
    }
    if ( _infix_q.Empty()  ){//make sure to pop untill the infix is empty
        while ( !_operator_s.empty() ) {  //or it will lose some stuff
            _postfix_q.push(_operator_s.pop());
        }
    }
    return _postfix_q;
}

