#ifndef QUEUE_FILE_H
#define QUEUE_FILE_H

#include <iostream>
#include <cassert>
#include "../../!includes/Iterator_list/list_iterator.h"

using namespace std;

template<typename T>
class Queue
{
public:

    class Iterator{
    public:
        friend class Queue;             //give access to list to access _ptr

        Iterator()                    //default ctor
        {
            //_ptr = nullptr;   Before, when I was doing stack_queue
            _ptr = typename List<T> :: Iterator();
        }
             //node<T>* p  Before when I was doing
        Iterator(typename List<T> :: Iterator ptr)        //Point Iterator to where p is pointing to
        {
            _ptr = ptr;
        }

        T& operator *()              //dereference operator
        {
            assert(_ptr);
           // return _ptr ->_item;  Before, when I was doing stack_queue
            return *_ptr;
        }

        T* operator ->()              //member access operator
        {
            assert(_ptr);
            return &(_ptr->_item);  //Before, when I was doing stack_queue
           // return &(*_ptr);
        }

        operator bool()              //casting operator: true if _ptr not NULL
        {
            if ( _ptr == nullptr ){
                return (false);
            }
            return (true);
        }

        bool is_null()                //true if _ptr is NULL
        {
            if ( _ptr == nullptr ){
                return (true);
            }
            return (false);
        }

        friend bool operator !=(const Iterator& left, const Iterator& right)
                                 //true if left != right
        {
            return (left._ptr != right._ptr);
        }

        friend bool operator ==(const Iterator& left, const Iterator& right)
                                 //true if left == right
        {
            return (left._ptr == right._ptr);
        }

        Iterator& operator++()    //member operator: ++it; or ++it = new_value
        {
            assert(_ptr);
            _ptr++;
           // _ptr = _ptr ->_next;  Before when I was doing stack_queue
            return *this;
        }

        friend Iterator operator++(Iterator& it, int unused)
                                          //friend operator: it++
        {
            Iterator hold;
            hold = it;
         //   it._ptr = it._ptr ->_next;   Before when I was doing stack_queue
         //   it++;
            ++it;
            return hold;
        }

    private:
       // node<T>* _ptr;  Before when I was doing stack_queue
        typename List<T> :: Iterator _ptr;
    };

    Queue();

    //big 3

    Queue(const Queue<T> &copyThis);

    Queue<T>& operator =(const Queue<T>& RHS);

    ~Queue();

    void push(const T& item);

    T pop();

    T front();

    T back();

//For shunting yard
    Iterator begin() const;
    Iterator end() const;

    bool Empty();

    template<class U>
    friend ostream& operator <<(ostream& outs, const Queue<U>& q);

private:
    List<T> _queue;
  //  typename List<T> :: Iterator _front;
    typename List<T> :: Iterator _rear;
    int _size;
};

template<typename T>
Queue<T> :: Queue()
{
   // _front = nullptr;
    _rear = nullptr;
    _size = 0;
}

//big 3

template <typename T>
Queue<T> :: Queue(const Queue<T> &copyThis)
{
    _size = copyThis._size;
    _rear = copyThis._rear;
    _queue = copyThis._queue;
}

template<typename T>
Queue<T>& Queue<T> :: operator =(const Queue<T>& RHS)
{
    if ( this == &RHS ){     //update version
        return *this;
    }

    _queue.clear();
    _size = RHS._size;
    _queue = RHS._queue;
    _rear = RHS._rear;

    return *this;
}

template<typename T>
Queue<T> :: ~Queue()
{
    _queue.clear();
}

template<typename T>
void Queue<T> :: push(const T& item)
{
    _size++;
    _rear = _queue.Insert_After(_rear,item);
    //my _insert_after always returns the location where the element inserted,
    //for this one, it returns the rear one.
}

template<typename T>
T Queue<T> :: pop()
{
    if ( _rear == _queue.Begin() ){
        _rear = nullptr;
    }
//    else {
//        _rear = _queue.Previous(_rear);
//    }


    return _queue.Delete(_queue.Begin());  // pop from the front
   // return _queue.Remove_Head();  <- not correct
}

template<typename T>
T Queue<T> :: front()
{
    //assert empty here because the user has to know that I assert the list
    //here even though i have done it in lower level functions
  //  assert(!_queue.empty());
    return *_queue.Begin();
}

template<typename T>
T Queue<T> :: back()
{
    return  *_queue.End();
}

//========================================
template<typename T>
typename Queue<T> :: Iterator Queue<T> :: begin() const
{
    return Iterator(_queue.Begin());
}

template<typename T>
typename Queue<T> :: Iterator Queue<T> :: end() const
{
    return Iterator(_queue.End());
}

template<typename T>
bool Queue<T> :: Empty()
{
    return _queue.empty();
}

template<class U>
ostream& operator <<(ostream& outs, const Queue<U>& q)
{
    q._queue.Print();
    return outs;
}

#endif // QUEUE_FILE_H
