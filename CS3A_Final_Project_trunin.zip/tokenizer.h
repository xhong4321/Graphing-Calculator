#ifndef TOKENIZER_H
#define TOKENIZER_H

#include <iostream>
#include <string.h>
#include <stdio.h>
#include "../../../Desktop/CS3/!includes/my_queue/queue_file.h"
#include "token.h"
#include "operator.h"
#include "rparen.h"
#include "lparen.h"
#include "function.h"
#include "number.h"
#include "variable.h"
#include <cmath>

using namespace std;

class Tokenizer
{
public:
    Tokenizer();
    Queue<Token*> get_infix(string input);
    void changed_to_infix( string part );
   // int get_number(string input);
private:
   Queue<Token*> infix_token;
};

#endif // TOKENIZER_H
