#include "tokenizer.h"

Tokenizer :: Tokenizer()//:infix_token(new Queue<char*>)
{
    //blank
}

Queue<Token*> Tokenizer :: get_infix( string input )
{
    //=============CLEAR=================
    while ( !infix_token.Empty() ) {
        infix_token.pop();
    }
    //===================================

    char str[input.length()+1];
    strcpy(str,input.c_str());
  //  cout << "tokenizer: " << str <<endl; //Good
    char* token;

    token = strtok(str," ");

    while ( token != NULL ) {
        changed_to_infix(token);
        token = strtok(NULL," ");
        //Since we have a "char*" now, I can call a function to convert it
        //to an infix expression now
//        cout << "print tokenizer while loop: ";
//        printf(" %s\n", token);
    }
    return infix_token;
}


void Tokenizer :: changed_to_infix( string part )
{
    int n = part.size();
    char str[n];
    strcpy(str, part.c_str());
   // cout << "changed to infix: " << str <<endl;
        for (int i = 0; i < n ; i++ ) {
            //find number
                    if( (int(str[0]) >= 49) && (int(str[0]) <= 57) ){
                        int number = 0; //intialize
                        if( isdigit(str[1]) ){
                            int n = 1;
                            while ( isdigit(str[n]) ) {
                                n++;
                            }
                            int i = 0;
                            while ( n > 0 ) {
                                number += (str[i] - '0')*(pow(10,(n-1)));
                                i++;
                                n--;
                            }

                        }
                        else {
                            number = str[0] - '0';
                        }
                        infix_token.push(new Number(number));
                    }
                    //All functions
                    else if ( (int(str[0]) >= 97) && (int(str[0]) <= 122) ) {
                        if ( int(str[0]) == 115 ){

                            infix_token.push(new Function("sin"));
                            break;
                        }
                        else if ( int(str[0])  == 99 ){
                            infix_token.push(new Function("cos"));
                            break;
                        }
                        else if (int(str[0])  == 116 ){
                            infix_token.push(new Function("tan"));
                            break;
                        }
                        else if ( int(str[0])  == 101 ){
                            if ( int(str[1]) == 120 ){
                                infix_token.push(new Function("exp"));
                                break;
                            }
                            infix_token.push(new Function("e"));
                            break;
                        }
                        else if ( int(str[0])  == 108 ){
                            if ( int(str[1]) == 110 ){
                                infix_token.push(new Function("ln"));
                                break;
                            }
                            infix_token.push(new Function("log"));
                            break;
                        }
                        else {
                            infix_token.push(new Variable("X"));
                            break;
                        }
                    }
                    //ALL VARIABLES
                    else if ( (int(str[0]) >= 65) && (int(str[0]) <= 90) ) {
                        infix_token.push(new Variable("X"));
                        break;
                    }
                    else {
                        //* / + - ^ ( )
                        if ( int(str[0]) == 43 ){
                            infix_token.push(new Operator("+"));
                        }
                        else if ( int(str[0]) == 42 ) {
                            infix_token.push(new Operator("*"));
                        }
                        else if ( int(str[0]) == 45 ) {
                            infix_token.push(new Operator("-"));
                        }
                        else if ( int(str[0]) == 47 ) {
                            infix_token.push(new Operator("/"));
                        }
                        else if ( int(str[0]) == 94 ) {
                            infix_token.push(new Operator("^"));
                        }
                        else if ( int(str[0]) == 40 ) {
                            infix_token.push(new LParen("("));
                        }
                        else if ( int(str[0]) == 41 ) {
                            infix_token.push(new RParen(")"));
                        }
                    }
        }

}

//============================================================================



//y = sin(1/X)  Good
//    infix.push(new Function("sin"));
//    infix.push(new LParen("("));
//    infix.push(new Number(1));
//    infix.push(new Operator("/"));
//    infix.push(new Variable("X"));
//    infix.push(new RParen(")"));

//y = tan(X)  Good
//    infix.push(new Function("tan"));
//    infix.push(new LParen("("));
//    infix.push(new Variable("X"));
//    infix.push(new RParen(")"));

//y=x^2  Good
//    infix.push(new Variable("X"));
//    infix.push(new Operator("^"));
//    infix.push(new Number(7));

//y=x^(1/2)*5-1  Good
//    infix.push(new Variable("X"));
//    infix.push(new Operator("^"));
//    infix.push(new LParen("("));
//    infix.push(new Number(1));
//    infix.push(new Operator("/"));
//    infix.push(new Number(2));
//    infix.push(new RParen(")"));
//    infix.push(new Operator("*"));
//    infix.push(new Number(5));
//    infix.push(new Operator("-"));
//    infix.push(new Number(1));

//y=ln(x^2-1)  Good
//    infix.push(new Function("ln"));
//    infix.push(new LParen("("));
//    infix.push(new Variable("X"));
//    infix.push(new Operator("^"));
//    infix.push(new Number(2));
//    infix.push(new Operator("-"));
//    infix.push(new Number(1));
//    infix.push(new RParen(")"));

//y=sin(tan(2*X))  Good
//    infix.push(new Function("sin"));
//    infix.push(new LParen("("));
//    infix.push(new Function("tan"));
//    infix.push(new LParen("("));
//    infix.push(new Number(2));
//    infix.push(new Operator("*"));
//    infix.push(new Variable("X"));
//    infix.push(new RParen(")"));
//    infix.push(new RParen(")"));

//y=sin(X*cos(X))  Good
//    infix.push(new Function("sin"));
//    infix.push(new LParen("("));
//    infix.push(new Variable("X"));
//    infix.push(new Operator("*"));
//    infix.push(new Function("cos"));
//    infix.push(new LParen("("));
//    infix.push(new Variable("X"));
//    infix.push(new RParen(")"));
//    infix.push(new RParen(")"));

//y=3^x  Good
//    infix.push(new Number(3));
//    infix.push(new Operator("^"));
//    infix.push(new Variable("X"));

//y=exp(x^2-1) Good
//    infix.push(new Function("exp"));
//    infix.push(new LParen("("));
//    infix.push(new Variable("X"));
//    infix.push(new Operator("^"));
//    infix.push(new Number(2));
//    infix.push(new Operator("-"));
//    infix.push(new Number(1));
//    infix.push(new RParen(")"));

//y=e^x  Good
//    infix.push(new Function("e"));
//    infix.push(new Operator("^"));
//    infix.push(new Variable("X"));

//y=3*X^2+2*X+1  Good
//    infix.push(new Number(3));
//    infix.push(new Operator("*"));
//    infix.push(new Variable("X"));
//    infix.push(new Operator("^"));
//    infix.push(new Number(2));
//    infix.push(new Operator("+"));
//    infix.push(new Number(2));
//    infix.push(new Operator("*"));
//    infix.push(new Variable("X"));
//    infix.push(new Operator("+"));
//    infix.push(new Number(1));
