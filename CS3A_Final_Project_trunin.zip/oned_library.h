#ifndef ONED_LIBRARY_H
#define ONED_LIBRARY_H


#include <iostream>
#include "../../!includes/find_shift_functions.h"

using namespace std;

template<typename T>
void init ( T* a, int size, const T& init_value = T() );

template<typename T>
T* add_entry(T* list, const T& new_entry, int& size, int& capacity);
//This is the function where I can receive the dynamic pointer and add one
//name to it, and also I can expand the capacity of the dynamic pointer

template<typename T>
T* remove_entry(T* list, const T& delete_me, int& size, int& capacity);
//This is the function where I can receive the dynamic pointer and remove
//one name based on the command, and also I can shrink the capacity of the
//dynamic pointer

template<typename T>
void delete_item( T key, T* list, int& size );
//This is where I'm going to use the file of "find_shift_functins" to
//delete one element from the dynamic pointer

template<typename T>
T* reallocate ( T* old_array, int& size, int& capacity );
//This is where I receive the dynamic pointer with full size, and I expand
//it to twice its capacity so that it's size is gonna be half of capacity
//when the function return the new dynamic pointer

template<typename T>
T* reallocate_for_set_size ( T* old_array, int size, int capacity );

template<typename T>
T* allocate ( int capacity );
//This is where the function receive the capacity and allocate it

template<typename T>
void copy_list(T *dest, T* src, int many_to_copy);
//After we have a new dynamic pointer with twice capacity but no elements
//in it, we are going to call theis function to fill the new dynamic
//pointer. At this point "dest" is new dynamic pointer, "src" is old
//dynamic pointer, and "many to_copy" is the size of elements in old one

template<typename T>
T* reallocate_remove ( T* old_array, int& size, int& capacity );
//Based on the rule, when the size reached the one fourth of capacity, the
//function is ging to allocate a half capacity dynamic pointer

template<typename T>
void print_list(T* list, int size);
//Print the result


//====================================================================




template<typename T>
void init ( T* a, int size, const T& init_value)
{
    T* walker = a;
    for ( int i = 0 ; i < size ; i++ ) {
        *walker = init_value;
        walker++;
    }
}

template<typename T>
T* allocate ( int capacity )
{
//    const bool debug = true;

//    if (debug)
//        cout << endl << "====allocate: capacity: "<< capacity
//             << endl << endl;
    //This is to remind that where the function got expanded

    return ( new T[capacity] );
}

template<typename T>
T* add_entry(T* list, const T& new_entry, int& size, int& capacity)
{
    T* walker = list;
    //declare a walker pointing to the pointer so that we don't mess up
    //the orignal pointer, we only move the walker

    if ( size == capacity )
    {   //If size equals to the capacity, we have to expand the capacity
        //means that we have to reallocate a new dynamic pointer

        T* new_list = reallocate ( walker, size, capacity );
        //declare a new name for the new dynamic pointer
        T* new_walker = new_list;
        //declare a new walker for the new dynamic pointer
        new_walker += size;
        //moves the walker to the correct location
        *new_walker = new_entry;
        //dereference the pointer
        size++;
        //expand the size by one because we just add an element

        return ( new_list ); //return the new dynamic pointer
    }
    else {
        //If size doesn't equal to the caacity
        //just dereference the pointer and expand the size
        walker += size;
        *walker = new_entry;
        size++;
        return ( list );
    }
}

template<typename T>
T* reallocate ( T* old_array, int& size, int& capacity )
{ //This function is for add entry
    capacity = capacity * 2;
    //where we expand the capacity when the size equals to the capacity
    T* new_array = allocate<T> ( capacity );
    //allocate a new dynamic pointer
    copy_list ( new_array, old_array, size );
    //call the copy function to copy all elements from old pointer to new
    //pointer
    delete [] old_array;
    //Then, deallocate the old pointer
    return ( new_array ); //return the new pointer
}

template<typename T>
T* reallocate_for_set_size ( T* old_array, int size, int capacity )
{
    T* new_array = allocate<T> ( capacity );
    //allocate a new dynamic pointer
    copy_list ( new_array, old_array, size );
    //call the copy function to copy all elements from old pointer to new
    //pointer
    delete [] old_array;
    //Then, deallocate the old pointer
    return ( new_array ); //return the new pointer
}

template<typename T>
void copy_list(T *dest, T* src, int many_to_copy)
{
    T* walker_dest = dest;
    T* walker_src = src;
    //Using the exactly same method that we used for the "fun_pointer"
    //to copy the stuff
    for ( int i = 0 ; i < many_to_copy ; i++ ) {
        *walker_dest = *walker_src;
        walker_dest++;
        walker_src++;
    }
}

template<typename T>
T* remove_entry(T* list, const T& delete_me, int& size, int& capacity)
{
    delete_item ( delete_me, list, size );
    //First, we call the "delete_item" file to delete "delete_me"
    if ( size == capacity / 4 )
    { //If size reaches one fourth of the capacity
        T* new_list = reallocate_remove ( list, size, capacity );
        //allocate a new dynamic pointer with half capacity

        return ( new_list ); //retrn the new dynamic pointer
    }
   // size--;        //when you call "delete_item",
                     //you have already deleted size by one.

    return ( list ); //Or return the original pointer
}

template<typename T>
T* reallocate_remove ( T* old_array, int& size, int& capacity )
{ //This function is for remove entry
    capacity = capacity / 2;
    //where we shrink the capacity when the size reaches one fourth
    //of the capacity
    T* new_array = allocate<T> ( capacity );

    copy_list ( new_array, old_array, size );

    delete [] old_array;     //Using the same method that we used for
                             //Add entry
    return ( new_array );
}

template<typename T>
void delete_item( T key, T* list, int& size )
{
    T* current = list;
  //  int initial_place = 0;
    T* end_of_array = list + size;
    while ( current != end_of_array )
    {
        T* location_of_repeats = find (key,  list , size);
        //declare a pointer that points to the location where the function
        //"find" found the repeats

        if ( location_of_repeats != nullptr){
            //If the function finds a value that is the same
            //compared to the value of current position
            int place = location_of_repeats - list;
            shift ( location_of_repeats, place , size );
        }
        else   //Might change "place"
        {
                          //move the place to the right
            current++;
        }
    }
  //  size--;      // You don't want to delete size by one here because
                 //you have alreaday deleted one in the "shift" function
}

template<typename T>
void print_list(T* list, int size)
{
    T* walker = list;
    //declare a walker pointing to the pointer

    for ( int i = 0 ; i < size ; i++ ) {
        cout << *walker << " ";
        walker++;  //moves the walker after output its value
    }
    cout << endl;
}



#endif // ONED_LIBRARY_H
