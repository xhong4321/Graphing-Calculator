#ifndef NODE_H
#define NODE_H

#include <iostream>
#include <cassert>

using namespace std;

template <typename T>
struct node{
  T _item;
  node<T>* _next;
  node(const T& item=T(), node<T>* next = nullptr):
                    _item(item), _next(next){}

    friend ostream& operator<<(ostream& outs, const node<T> n){
        outs<<n._item;
        return outs;
    }
};

template<typename T>
node<T>* _insert_head(node<T>*& head_ptr, const T& item);

template<typename T>
node<T>* _insert_after(node<T>*& head_ptr,  node<T>* mark, const T& item);

template<typename T>
node<T>* _search(node<T>*& head_ptr, const T& item);

template<typename T>
T _delete ( node<T>*& head_ptr, node<T>* deleteThis );

template<typename T>
T _remove_head ( node<T>*& head_ptr );

template<typename T>
bool _empty(node<T>* head_ptr);

template <typename T>
node<T>* _WhereThisGoes(node<T>* head_ptr,           //node after which this
                       T item,           // item goes
                       bool ascending=true);    //order: 0 ascending

template <typename T>
node<T>* _InsertBefore(node<T>*& head_ptr,       //insert before ptr
                      node<T>* beforeThis,
                      const T& insertThis);

template <typename T>        //ptr to previous node
node<T>* _PreviousNode(node<T>* head_ptr, node<T>* prevToThis);

template <typename T>        //ptr to next node
node<T>* _NextNode(node<T>* head_ptr, node<T>* nextToThis);

template<typename T>      //insert i. Assume sorted list
node<T>* _InsertSorted(node<T>*& head_ptr, const T& item, bool ascending = true);

template<typename T>      //insert i. Assume sorted list
node<T>* _Insert_iterator(node<T>*& head_ptr, const T& item, bool ascending = true);

template <typename T>
node<T>* _CopyList(node<T>* head_ptr, node<T>*& copy); //duplicate the list...

template <typename T>
void _ClearList(node<T>*& head_ptr);                     //delete all the nodes

template <typename T>
node<T>* _LastNode(node<T>* head_ptr);            //Last Node in the list

template <typename T>
T& At(node<T>* head_ptr, int pos);              //_item at this position

//template<typename T>
//ostream& _print_list(node<T>* head_ptr, node<T>* cursor, ostream& outs = cout);

template <typename T>
void _print_list(node<T>* head_ptr);

//============================================================================

template<typename T>
node<T>* _insert_head(node<T>*& head_ptr, const T& item){
    //insert the item at the head of the list: make it the first j
    //      link in the chain.

    //1: create a new node:
    node<T>* temp = new node<T>(item);
    //2. point (the next field of) this new node to where head is pointing to
    temp->_next = head_ptr;

    //3. point head to this new node:
    head_ptr = temp;

    return head_ptr;
}

template<typename T>
node<T>* _insert_after(node<T>*& head_ptr, node<T>* mark, const T& item)
{
    node<T>* temp = new node<T>(item);
    if ( head_ptr == nullptr ){         //this is only happens when we run
        head_ptr = _insert_head(head_ptr,item);           //it first time
        return head_ptr;
    }
    else if ( mark ->_next == nullptr ) {
        temp ->_next = nullptr;
        mark ->_next = temp;
        return temp;
    }
    else {
        temp->_next = mark ->_next;
        mark ->_next = temp;
        return temp;
    }
}

template<typename T>
node<T>* _search(node<T>*& head_ptr, const T& item)
{
    node<T>* walker = head_ptr;
    if ( walker == nullptr ){
        return nullptr;
    }
    while ( walker != nullptr ) {
        if ( (*walker)._item == item ){
            return walker;
        }
        walker = walker ->_next;
    }
    return nullptr;
}

template<typename T>
T _delete ( node<T>*& head_ptr, node<T>* deleteThis )
{
    assert(head_ptr != nullptr);
    T item = (*deleteThis)._item;
    if ( deleteThis == head_ptr ){
        return _remove_head(head_ptr);
    }
    node<T>* walker = head_ptr;
    while ( walker ->_next != deleteThis ) {
        walker = walker ->_next;
    }
    walker ->_next = deleteThis ->_next;   //HOPE THIS IS CORRECT
    delete deleteThis;
    return item;
}

template<typename T>
T _remove_head ( node<T>*& head_ptr )
{
    assert ( head_ptr != nullptr );
    node<T>* walker = head_ptr;
    head_ptr = walker ->_next;
    T item = (*walker)._item;
    delete walker;
    return item;
}

template<typename T>
bool _empty(node<T> *head_ptr)
{
    if ( head_ptr == nullptr ){
        return true;
    }
    return false;
}

template <typename T>
node<T>* _WhereThisGoes(node<T>* head_ptr, T item, bool ascending)
{
    node<T>* leader_walker = head_ptr ->_next;
    node<T>* walker = head_ptr;
    if ( ascending ){             //For ascending
        while ( (*leader_walker)._item < item &&  leader_walker ->_next != nullptr )
        {
            leader_walker = leader_walker ->_next;
            walker = walker ->_next;
        }
        if ( leader_walker ->_next == nullptr ){
            if ( leader_walker->_item < item ){
                return walker;
            }
            return leader_walker;
        }
        return walker;
    }
    else {                         //For descending
        while ( (*leader_walker)._item > item  && leader_walker ->_next != nullptr )
        {
            leader_walker = leader_walker ->_next;
            walker = walker ->_next;
        }
        if ( leader_walker ->_next == nullptr ){
            if ( leader_walker->_item < item ){
                return walker;
            }
            return leader_walker;
        }
        return walker;
    }
}

template <typename T>       //insert before ptr
node<T>* _InsertBefore(node<T>*& head_ptr, node<T>* beforeThis,
                      const T& insertThis)
{
    node<T>* temp = new node<T>(insertThis);
    node<T>* walker = head_ptr;
    if (head_ptr == nullptr || beforeThis == head_ptr ){
        head_ptr = _insert_head(head_ptr,insertThis);
        return head_ptr;
    }
    while ( walker ->_next != beforeThis ) {
        walker = walker ->_next;
    }
    temp ->_next = beforeThis;
    walker ->_next = temp;
    return temp;
}

template <typename T>        //ptr to previous node
node<T>* _PreviousNode(node<T>* head_ptr, node<T>* prevToThis)
{
    assert(prevToThis != nullptr && head_ptr != nullptr);
    node<T>* walker = head_ptr;
    if ( prevToThis == head_ptr ){
        return head_ptr;
    }
    while ( walker ->_next != prevToThis ) {
        walker = walker ->_next;
    }
    return walker;
}

template <typename T>        //ptr to next node
node<T>* _NextNode(node<T>* head_ptr, node<T>* nextToThis)
{
    node<T>* walker = nextToThis;
    if ( nextToThis == nullptr ){
        return nullptr;
    }
//    else if ( walker ->_next == nullptr ) {
//        return nextToThis;    Comment this out for Iterator ++ operator
//    }
    walker = walker ->_next;
    return walker;
}

template<typename T>      //insert i. Assume sorted list
node<T>* _InsertSorted(node<T>*& head_ptr,const T& item, bool ascending)
{
    //if empty
    if ( head_ptr == nullptr ){
        head_ptr = _insert_head(head_ptr,item);
        return head_ptr;
    }
    //if there is only one element
    if ( head_ptr ->_next == nullptr){
        if ( head_ptr ->_item > item ){
            return _insert_after (head_ptr,head_ptr,item);
        }
        else {
            return _InsertBefore (head_ptr,head_ptr,item);
        }
    }
    node<T>* temp = new node<T>(item);
    node<T>* walker = _WhereThisGoes( head_ptr,item,ascending );
    //if the head pointer is less than item
    if ( head_ptr ->_item < item ){
        return _InsertBefore( head_ptr,head_ptr,item );
    }
    else if ( walker ->_item == item ){    //they are the same
        return _InsertBefore(head_ptr,walker,item);
    }
    temp = _insert_after( head_ptr,walker,item );
    return temp;
}


//need to change
template<typename T>      //insert i. Assume sorted list
node<T>* _InsertSorted_and_add(node<T>*& head_ptr, const T& item, bool ascending)
{
    //if empty
    if ( head_ptr == nullptr ){
        head_ptr = _insert_head(head_ptr,item);
        return head_ptr;
    }
    //if there is only one element
    if ( head_ptr ->_next == nullptr){
        if ( head_ptr ->_item == item ){
            head_ptr ->_item += item;
            return head_ptr;
        }
        if ( head_ptr ->_item > item ){
            return _insert_after (head_ptr,head_ptr,item);
        }
        else {
            return _InsertBefore (head_ptr,head_ptr,item);
        }
    }
    node<T>* temp = new node<T>(item);
    node<T>* walker = _WhereThisGoes( head_ptr,item,ascending );
    //if the head pointer is less than item
    if ( head_ptr ->_item < item ){
        return _InsertBefore( head_ptr,head_ptr,item );
    }
    //the next one is nullptr, but they are not the same
    else if ( walker ->_next == nullptr && walker ->_item != item ){
        return _insert_after( head_ptr,walker,item );
    }
    else if ( walker ->_item == item ) {    //they are the same
        walker ->_item += item;
        return walker;
    }
    // the next one is equal to item
    else if ( (walker ->_next) ->_item == item ){
        (walker ->_next) ->_item += item;
        return walker ->_next;
    }
    temp = _insert_after( head_ptr,walker,item );
    return temp;
}

template <typename T>
node<T>* _CopyList(node<T>* head_ptr, node<T>*& copy) //duplicate the list...
{
    assert(head_ptr != nullptr);
    if(head_ptr == copy)
    {
        return _LastNode(head_ptr);
    }
    // deallcate the nodes
    _ClearList(copy);
    // let the head of the copy points to the first node
    copy = new node<T>((*head_ptr)._item);
    node<T>* copyWalker = copy;
    while( head_ptr ->_next != nullptr)
    {
        // the next node within about to be copied
        head_ptr = head_ptr ->_next;
        // insert the item after copyWalker with the copy list
        _insert_after(copy, copyWalker, (*head_ptr)._item);
        // goes to the next newly added node with copy list
        copyWalker = copyWalker ->_next;
    }

        // return the address of the last noed within the copy list
    return copyWalker;
}

template <typename T>
void _ClearList(node<T>*& head_ptr)             //delete all the nodes
{
    while ( head_ptr != nullptr ) {
        _remove_head(head_ptr);
    }
}

template <typename T>
T& At(node<T>* head_ptr, int pos)             //_item at this position
{
    if ( head_ptr == nullptr ){
    }
    node<T>* walker = head_ptr;
    for ( int i = 0 ; i < pos ; i++ ) {
        walker = walker ->_next;
    }
    return (*walker)._item;
}

template <typename T>
node<T>* _LastNode(node<T>* head_ptr)            //Last Node in the list
{
    node<T>* walker = head_ptr;
    if ( head_ptr == nullptr ){
        return nullptr;
    }
    while ( walker ->_next != nullptr ) {
        walker = walker ->_next;
    }
    return walker;
}

template<typename T>
void _print_list(node<T>* head_ptr){
    cout << "HH->";      //can be done in while loop
    node<T>* walker = head_ptr;
    while (walker != nullptr)
    {
        cout << "[" << *walker << "]->";
        walker = walker ->_next;
    }
    cout << "|||";
    cout << endl;
}

//template<typename T>
//T& _remove_head_finalP ( node<T>*& head_ptr );

//template<typename T>
//T& _remove_head_finalP ( node<T>*& head_ptr )
//{
//    assert ( head_ptr != nullptr );
//    node<T>* walker = head_ptr;
//    head_ptr = walker ->_next;
//    T item = (*walker)._item;
//    delete walker;
//    return *head_ptr;  //maybe correct
//}

#endif // NODE_H
