#ifndef PLOT_H
#define PLOT_H

#include <vector>
#include <SFML/Graphics.hpp>
#include "rpn.h"
#include "coord_translation.h"
#include "function.h"
#include "lparen.h"
#include "rparen.h"
#include "number.h"
#include "operator.h"
#include "variable.h"
#include "graph_info.h"
#include "tokenizer.h"

using namespace std;

class Plot
{
public:
    Plot(Graph_info* info);
    void set_info(Graph_info* info);
    vector<sf::Vector2f> operator()();
private:
    Graph_info* _info;
  //  shunting_yard sy;
    Queue<Token*> _post_fix;
    Coord_translation _c_translate;
    Tokenizer _tokenizer;
};


#endif // PLOT_H
