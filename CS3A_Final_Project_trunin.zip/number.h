#ifndef NUMBER_H
#define NUMBER_H

#include <iostream>
#include "token.h"

using namespace std;

class Number : public Token
{
public:
    Number();
    Number( double number );

    virtual int type0f();
    virtual void print();
    virtual double actual_number();
private:
    double _number;
};

#endif // NUMBER_H
