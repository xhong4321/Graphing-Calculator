#ifndef OPERATOR_H
#define OPERATOR_H


#include <iostream>
#include "token.h"
#include "string.h"

using namespace std;

class Operator : public Token
{
public:
    Operator();
    Operator ( string op );

    virtual int type0f();
    virtual void print();
    virtual int Prec();
    virtual int char_num();

private:
    string _op;
    int _prec;
};

#endif // OPERATOR_H
