#include "lparen.h"

LParen::LParen()
{
    //blank
}

LParen :: LParen(string lp): _lp(lp)
{
    //blank
}

int LParen :: type0f()
{
    return LPAREN;
}

void LParen :: print()
{
    cout << _lp << " ";
}
