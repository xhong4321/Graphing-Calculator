#include "number.h"

Number::Number()
{
    //blank
}

Number :: Number(double number) : _number(number)
{
    //blank
}

int Number :: type0f()
{
    return NUMBER;
}

void Number :: print()
{
    cout << _number <<" ";
}

double Number :: actual_number()
{
    return _number;
}
