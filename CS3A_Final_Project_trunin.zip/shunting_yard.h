#ifndef SHUNTING_YARD_H
#define SHUNTING_YARD_H


#include <iostream>
#include "../../../Desktop/CS3/!includes/my_stack/stack_file.h"
#include "../../../Desktop/CS3/!includes/my_queue/queue_file.h"
#include "token.h"
#include "number.h"

using namespace std;

class shunting_yard
{
public:

    shunting_yard();
    shunting_yard( Queue<Token*> infix_q );

    Queue<Token*> postfix(  );

private:
    Queue<Token*> _infix_q;
    Stack<Token*> _operator_s;
    Queue<Token*> _postfix_q;
};

#endif // SHUNTING_YARD_H
