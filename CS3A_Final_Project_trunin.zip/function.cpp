#include "function.h"

Function::Function()
{
    //blank
}

Function :: Function (string op): Operator(op), _func(op)
{
    //blank
}

int Function :: type0f()
{
    return OPERATOR;
}

//void Function :: print()
//{
//    cout <<  << " ";
//}

int Function :: char_num()
{
    char c_num = _func[0];
    int num = int(c_num);
    if ( num == 108 ){
        char c_num_2 = _func[1];
        if ( c_num_2 == 110 ){ //ln
            return int(c_num_2);
        }
        return 111;  //log
    }
    else if ( num == 101 ) {
        char c_num_2 = _func[1];
        if( c_num_2 == 120 ){
            return int(c_num_2);  //exp
        }
     //   return num;  //e
    }
    return num;
}
