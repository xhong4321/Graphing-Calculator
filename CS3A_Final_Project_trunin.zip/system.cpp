#include "system.h"
#include "random.h"
#include <iostream>
#include <constants.h>

System::System(Graph_info* info): _info(info), _graph(_info)
{
    //blank
}

void System :: set_info(Graph_info* info)
{
    _info->_domain = info->_domain;
    _info->_points = info->_points; //This one will not change at all
    _info->_orgin = info->_orgin;
    _info->_window_dimemsions = info->_window_dimemsions;
    _info->_scale = info->_scale;
}

void System::Step(int command, Graph_info *info){
    float number_zoom = 0.7;
    float number_UD = 0.15;
    float number_pan = 0.1;
   // cout << "step" << endl;
    set_info(info);
    if ( command == CMD_NEW_EQUATION ){
        _info->_equation = info->_equation;
    }
    else if ( command == CMD_ZOOM_IN ) {
       // Multi a number to make it smaller
        _info->_domain.x *= number_zoom;
        _info->_domain.y *= number_zoom;
        _info->_scale.x = _info->_window_dimemsions.x/(
                    (_info->_domain.y)-(_info->_domain.x));
        //Prepare for pan up/down
        _info->_range.x *= number_zoom;
        _info->_range.y *= number_zoom;
    }
    else if ( command == CMD_ZOOM_OUT ) {
        //divide a number to make it larger
        _info->_domain.x /= number_zoom;
        _info->_domain.y /= number_zoom;
        _info->_scale.x = _info->_window_dimemsions.x/(
                    (_info->_domain.y)-(_info->_domain.x));
        //Prepare for pan up/down
        _info->_range.x *= number_zoom;
        _info->_range.y *= number_zoom;
    }
    else if ( command == CMD_PAN_LEFT ) {
        //We have to use ratio between the real window and the x-axis
        float temp = _info->_window_dimemsions.x * number_pan;
        float temp2 = _info->_domain.y - _info->_domain.x;
        //the origin that we moved is different from the x-axis
        _info->_orgin.x += temp;
        _info->_domain.x -= temp/(_info->_window_dimemsions.x/temp2);
        _info->_domain.y -= temp/(_info->_window_dimemsions.x/temp2);
    }
    else if ( command == CMD_PAN_RIGHT ) {
        float temp = _info->_window_dimemsions.x * number_pan;
        float temp2 = _info->_domain.y - _info->_domain.x;
        _info->_orgin.x -= temp;
        _info->_domain.x += temp/(_info->_window_dimemsions.x/temp2);
        _info->_domain.y += temp/(_info->_window_dimemsions.x/temp2);
    }
    else if ( command == CMD_RESET ) {
        //Copy from the set_info of animate
        _info->_window_dimemsions = sf::Vector2f(SCREEN_WIDTH_WITHOUT_SBAR,
                                                 SCREEN_HEIGHT);
        _info->_domain = sf::Vector2f(-5,5);
        _info->_points = POINTS;
        float xpos = SCREEN_WIDTH_WITHOUT_SBAR / 2;
        float ypos = SCREEN_HEIGHT /2;
        _info->_orgin = sf::Vector2f(xpos,ypos);
        _info->_scale = sf::Vector2f(_info->_window_dimemsions.x/(
                                   (_info->_domain.y)-(_info->_domain.x)),0);
    }
    else if ( command == CMD_PAN_UP ) {
        //drop the y-axis
        _info->_orgin.y -= (_info->_window_dimemsions.y/
                            (_info->_range.y-_info->_range.x))*number_UD;
    }
    else if ( command == CMD_PAN_DOWN ) {
        //move up the y-axis
        _info->_orgin.y += (_info->_window_dimemsions.y/
                            (_info->_range.y-_info->_range.x))*number_UD;
    }

//    cout << "step call graph update" << endl;
    _graph.update(_info);
}


void System::Draw(sf::RenderWindow& window){
    _graph.draw(window);

}
