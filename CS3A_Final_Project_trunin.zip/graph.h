#ifndef GRAPH_H
#define GRAPH_H

#include <iostream>
#include <vector>
#include <SFML/Graphics.hpp>
#include "plot.h"
#include "graph_info.h"

using namespace std;

class Graph
{
public:
    Graph(Graph_info* info); //To be continued
    void set_info(Graph_info* info);
    void update(Graph_info* info);
    void draw(sf::RenderWindow& window);
private:
    Graph_info* _info;
    vector<sf::Vector2f> _points;
    Plot _plot;
};

#endif // GRAPH_H
