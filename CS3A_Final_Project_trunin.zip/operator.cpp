#include "operator.h"

Operator::Operator(): _op(""), _prec(0)
{
    //blank
}

Operator :: Operator ( string op )
{
    _op = op;
    if ( op == "*" ){
        _prec = MUL_PREC;
    }
    else if ( op == "/" ) {
        _prec = DIV_PREC;
    }
    else if ( op == "+" ) {
        _prec = ADD_PREC;
    }
    else if ( op == "-" ) {
        _prec = SUB_PREC;
    }
    else if ( op == "^" ){
        _prec = POWER_PREC;
    }
    else {
        _prec = TRIG_PREC;
    }
}

int Operator :: type0f()
{
    return OPERATOR;
}

void Operator :: print()
{
    cout << _op << " ";
}

int Operator :: Prec()
{
    return _prec;
}

int Operator :: char_num()
{
    char s = _op[0];
    int num = int(s);
    return num;
}
