#ifndef STACK_FILE_H
#define STACK_FILE_H

#include <iostream>
#include <cassert>
#include "../../!includes/node/node.h"

using namespace std;

template<typename T>
class Stack{
public:

    class Iterator{
    public:
        friend class Stack;             //give access to list to access _ptr

        Iterator()                    //default ctor
        {
            _ptr = NULL;
        }

        Iterator(node<T>* p)        //Point Iterator to where p is pointing to
        {
            _ptr = p;
        }

        T& operator *()              //dereference operator
        {
            assert(_ptr);
            return _ptr ->_item;
        }

        T* operator ->()              //member access operator
        {
            assert(_ptr);
           // return _ptr;
            return &(_ptr->_item);
        }

        operator bool()              //casting operator: true if _ptr not NULL
        {
            if ( _ptr == nullptr ){
                return (false);
            }
            return (true);
        }

        bool is_null()                //true if _ptr is NULL
        {
            if ( _ptr == nullptr ){
                return (true);
            }
            return (false);
        }

        friend bool operator !=(const Iterator& left, const Iterator& right)
                                 //true if left != right
        {
            return (left._ptr != right._ptr);
        }

        friend bool operator ==(const Iterator& left, const Iterator& right)
                                 //true if left == right
        {
            return (left._ptr == right._ptr);
        }

        Iterator& operator++()    //member operator: ++it; or ++it = new_value
        {
            _ptr = _ptr ->_next;
            return *this;
        }

        friend Iterator operator++(Iterator& it, int unused)
                                          //friend operator: it++
        {
            Iterator hold;
            hold = it;
            it._ptr = it._ptr ->_next;
            return hold;
        }

    private:
        node<T>* _ptr;
    };

    Stack();

    //big 3:

    Stack(const Stack<T> &copyThis);

    Stack<T>& operator =(const Stack<T>& RHS);

    ~Stack();

    void push(const T& item);

    T pop();

    T front() const;

 //   T back() const;

    bool empty();

    template<class U>
    friend ostream& operator <<(ostream& outs, const Stack<U>& s);

private:
    node<T>* _top;
};

//============================================================================

template<typename T>
Stack<T> :: Stack()
{
    _top = nullptr;
}

//big 3:

template<typename T>
Stack<T> :: Stack(const Stack<T> &copyThis)
{
    _top = nullptr;
    _CopyList(copyThis._top,_top);
}

template<typename T>
Stack<T>& Stack<T> :: operator =(const Stack<T>& RHS)
{
    if ( this == &RHS ){
        return *this;
    }
    //clear is in copylist
    _CopyList(RHS._top,_top);
    return *this;
}

template<typename T>
Stack<T> :: ~Stack()
{
    _ClearList(_top);
}

template<typename T>
void Stack<T>::push(const T& item)
{
    _insert_head(_top,item);
}

template <typename T>
T Stack<T> :: pop()
{

    return _remove_head(_top);
}

template <typename T>
T Stack<T> :: front() const
{
    //assert empty here because the user has to know that I assert the list
    //here even though i have done it in lower level functions
  //  assert(!_top);
    return _top->_item;
}

//template<typename T>
//T Stack<T> :: back() const
//{
//    return
//}

template <typename T>
bool Stack<T> :: empty()
{
    return _empty(_top);
}

template<class U>
ostream& operator <<(ostream& outs, const Stack<U>& s)
{
    _print_list(s._top);
    return outs;
}

 //   T& pop_finalP();

//template<typename T>
//T& Stack<T> :: pop_finalP()
//{
//    return _remove_head_finalP(_top);
//}

#endif // STACK_FILE_H
