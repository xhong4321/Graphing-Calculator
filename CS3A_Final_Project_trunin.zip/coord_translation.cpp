#include "coord_translation.h"

Coord_translation::Coord_translation(Graph_info* info): _info(info)
{
    //blank
}

sf::Vector2f Coord_translation :: translate(sf::Vector2f point)
{
    float o_xpos = _info->_orgin.x;
    float o_ypos = _info->_orgin.y;

    return sf::Vector2f((_info->_scale.x)*(point.x)+o_xpos
                        ,o_ypos-(_info->_scale.x)*(point.y));
}
