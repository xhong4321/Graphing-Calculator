#include "graph.h"

Graph :: Graph(Graph_info* info): _info(info), _plot(info)
{
    //blank
}

void Graph :: set_info(Graph_info* info)
{
    _info->_equation = info->_equation;
    _info->_orgin = info->_orgin;
    _info->_scale = info->_scale;
    _info->_domain = info->_domain;
    _info->_points = info->_points;
    _info->_window_dimemsions = info->_window_dimemsions;
    _plot.set_info(_info); //chnage the info in plot.h
}

void Graph :: update(Graph_info *info)
{
    set_info(info);
    cout << "graph call plot " << endl;
    _points = _plot();
}

void Graph :: draw(sf::RenderWindow& window)
{
    sf::RectangleShape x_axis;
    sf::RectangleShape y_axis;
    //Using RectangleShapes to draw the x-axis and y-axis
    x_axis.setSize(sf::Vector2f(SCREEN_WIDTH_WITHOUT_SBAR,1));
    x_axis.move(sf::Vector2f(0,_info->_orgin.y));
    x_axis.setFillColor(sf::Color::Black);
    window.draw(x_axis);

    y_axis.setSize(sf::Vector2f(1,SCREEN_HEIGHT));
    y_axis.move(sf::Vector2f(_info->_orgin.x,0));
    y_axis.setFillColor(sf::Color::Black);
    window.draw(y_axis);

    //draw the points on thr graph
    sf::CircleShape shape;
    shape = sf::CircleShape(1);
    for ( int i = 0 ; i < _points.size() ; i++ ) {
        shape.setPosition(_points[i]);
        shape.setFillColor(sf::Color::Blue);
        window.draw(shape);
    }
}
