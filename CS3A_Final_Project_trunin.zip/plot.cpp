#include "plot.h"

Plot::Plot(Graph_info* info): _info(info), _c_translate(_info)
{
    //blank
}

void Plot :: set_info(Graph_info* info)
{
    _info->_equation = info->_equation;
    _info->_orgin = info->_orgin;
    _info->_scale = info->_scale;
    _info->_domain = info->_domain;
    _info->_points = info->_points;
    _info->_window_dimemsions = info->_window_dimemsions;
   // cout << " plot:  " << _info->_equation <<endl;    //correct
}

vector<sf::Vector2f> Plot::operator()()

{
    cout << "****plot _info_equation: " << _info->_equation <<endl;

    vector<sf::Vector2f> points;

    if ( _info->_equation != "" ){

        Queue<Token*> infix_token = _tokenizer.get_infix(_info->_equation);

        Queue<Token*> infix = infix_token;

//        int n = _tokenizer.get_number(_info->_equation);

//        for ( int i = 0 ; i<n ; i++ ){
//            Token* j = infix.pop();
//            j->print();
//            cout <<endl;
//        }

        shunting_yard sy(infix);

        _post_fix = sy.postfix();

        Rpn _rpn(_post_fix);
        float x_min = _info->_domain.x;
        float x_max = _info->_domain.y;
        float increment = (x_max - x_min)/_info->_points;
        float ypos;
        for ( double x = x_min ; x <= x_max ; x+=increment ) {
            Rpn _rpn(_post_fix);
            cout << "[x_value]: " << x;
            ypos = _rpn.Evaluate(x);
            cout << "[y_value]: " << ypos;
            sf::Vector2f point(x,ypos);
            point = _c_translate.translate(sf::Vector2f (point));
            points.push_back(point);
        }
        cout << endl;
    }
    cout << "99999999999999999999999999999999" << endl;
    return points;
}
