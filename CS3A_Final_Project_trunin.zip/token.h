#ifndef TOKEN_H
#define TOKEN_H


#include <iostream>


//=========================
const int NUMBER = 5;
const int VARIABLE = 6;
const int OPERATOR = 7;
//const int FUNCTION = 7;
const int LPAREN = 8;
const int RPAREN = 9;
const int ADD_PREC = 2;
const int SUB_PREC = 2;
const int DIV_PREC = 3;
const int MUL_PREC = 3;
const int TRIG_PREC = 4;
const int POWER_PREC = 5;
//=========================

using namespace std;

class Token
{
public:
    Token();

    virtual int type0f();
    virtual void print();
    virtual int Prec();
    virtual int char_num();
    virtual double actual_number();

};

#endif // TOKEN_H
