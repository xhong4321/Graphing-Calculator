#ifndef FUNCTION_H
#define FUNCTION_H


#include <iostream>
#include "operator.h"
#include "string.h"

using namespace std;

class Function : public Operator
{
public:
    Function();
    Function (string op);
    virtual int type0f();
    virtual int char_num();
   // virtual void print();
private:
    string _func;
};

#endif // FUNCTION_H
