#ifndef FIND_SHIFT_FUNCTIONS_H
#define FIND_SHIFT_FUNCTIONS_H

#include <iostream>

using namespace std;

template <typename T>
T* find( T key, T* b, int size ); //Declare the find function
//This function returns the address of pointer
//that points to the same value

template <typename T>
void shift ( T* c, int start, int& size ); //Delcare the shift function
//This function shift all the variables that on the right side of the
//address to the left for one spot.



template <typename T>
T *find( T key, T* b, int size )
{

  //  T* current_target;
  //  current_target = b + start; //point the pointer to the current position

    for ( int i = 0 ; i < size ; i++ ) {
        if ( *b == key ){ //&& ( b != current_target )
            return b;  //if the pointer finds a value that is the same with
                       //the value of the current position, and the pointer
                                 //is not at the current position
                                 //Then, return the position of the pointer
        }

        b++;                     //if not, move the pointer to the right

    }

    return nullptr; //return nullptr if the function didn't find
}

template <typename T>
void shift ( T* c, int start, int& size )
//The method how I shift elements is that the function will get a
//different number of 'start' and 'size'. And the function is going to
//shift the elements between this range

{
    T* next = c;    //First, make the pointer to point to the array
    next++;         //Then, make the pointer points to the next position
    T* walker = c;
    walker += start;
    next += start;
    for ( ; start < size ; start++ ) {
        *walker = *next;     //shift the next value to the current position
        walker++;        //move the ponter current to the right
        next++;     //move the pointer next to the right
    }

    size--;     //decrease the size by 1

}


#endif // FIND_SHIFT_FUNCTIONS_H
