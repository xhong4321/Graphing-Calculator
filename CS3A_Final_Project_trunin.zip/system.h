#ifndef SYSTEM_H
#define SYSTEM_H
#include <vector>
#include <SFML/Graphics.hpp>
#include "graph.h"
#include "graph_info.h"
//#include "iomanip"

using namespace std;

class System
{
public:
    System(Graph_info* info);
    void set_info(Graph_info* info);
    void Step(int command, Graph_info* info);
    int Size();
    void Draw(sf::RenderWindow& widnow);
    string get_domain();
private:
    Graph_info* _info;
    sf::CircleShape shape;
    sf::Vector2f vel;
    Graph _graph;
};

#endif // SYSTEM_H
