#include "variable.h"

Variable::Variable(): _var("")
{
    //blank
}

Variable :: Variable( string var ): _var(var)
{
    //blank
}

int Variable :: type0f()
{
    return VARIABLE;
}

void Variable :: print()
{
    cout << _var << " ";
}

int Variable :: char_num()
{
    char s = _var[0];
    int num = int(s);
    return num;
}
