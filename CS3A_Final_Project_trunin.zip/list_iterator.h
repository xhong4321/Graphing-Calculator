#ifndef LIST_ITERATOR_H
#define LIST_ITERATOR_H

#include <iostream>
#include <cassert>
#include "../../!includes/node/node.h"

using namespace std;

template <typename T>
class List{
public:

    class Iterator{
    public:
        friend class List;             //give access to list to access _ptr

        Iterator()                    //default ctor
        {
            _ptr = NULL;
        }

        Iterator(node<T>* p)        //Point Iterator to where p is pointing to
        {
            _ptr = p;
        }

        T& operator *()              //dereference operator
        {
            assert(_ptr);
            return _ptr ->_item;
        }

        T* operator ->()              //member access operator
        {
        //    assert(_ptr);
           // return _ptr;
            return &(_ptr->_item);
        }

        operator bool()              //casting operator: true if _ptr not NULL
        {
            if ( _ptr == nullptr ){
                return (false);
            }
            return (true);
        }

        bool is_null()                //true if _ptr is NULL
        {
            if ( _ptr == nullptr ){
                return (true);
            }
            return (false);
        }

        friend bool operator !=(const Iterator& left, const Iterator& right)
                                 //true if left != right
        {
            return (left._ptr != right._ptr);
        }

        friend bool operator ==(const Iterator& left, const Iterator& right)
                                 //true if left == right
        {
            return (left._ptr == right._ptr);
        }

        Iterator& operator++()    //member operator: ++it; or ++it = new_value
        {
            _ptr = _ptr ->_next;
            return *this;
        }

        friend Iterator operator++(Iterator& it, int unused)
                                          //friend operator: it++
        {
            Iterator hold;
            hold = it;
            it._ptr = it._ptr ->_next;
            return hold;
        }

    private:
        node<T>* _ptr;
    };

    List(bool order=false, bool unique=false);     //CTOR with default args

    //big 3 functions:

    List(const List<T> &copyThis);

    List<T>& operator =(const List<T>& RHS);

    ~List();

    Iterator Insert(const T& i);        //Insert i in a sorted manner

    Iterator search (const T& item);

    Iterator Previous(List<T> :: Iterator iMarker);    //get the previous node to iMarker

    //for Queue
    Iterator Insert_After(List<T> :: Iterator iMarker, const T& item);

    Iterator Insert_Head(const T& item);

    T Remove_Head();

    T Delete(List<T> :: Iterator iMarker);

    bool empty();

    bool is_descending() const;  //for polynomial_Linked_list

    void Print() const;            //print the list

    const T& operator[](const int index) const;//const version of the operator [ ]

    T& operator[](const int index);       //return the item at index

    Iterator Begin() const;        //return the head of the list

    Iterator End() const;          //return the tail of the list

    void clear();

    template <class U>
    friend ostream& operator<<(ostream& outs, const List<U>& l);

    Iterator NextNode(Iterator iMarker);

private:
    node<T>* _head_ptr;
    bool _order;
    bool _unique;
};

template<typename T>
List<T> :: List(bool order , bool unique )
{
    _order = order;
    _unique = unique;
    _head_ptr = nullptr;
}

template <typename T>
typename List<T> :: Iterator List<T> :: Insert(const T& item)
//insert i. Assume sorted list
{
    if (_unique){
        return Iterator(_InsertSorted_and_add(_head_ptr,item,_order));
    }
    return Iterator(_InsertSorted(_head_ptr,item,_order));
}

//-------------------Big 3--------------------

template<typename T>
List<T> :: List(const List<T> &copyThis)
{
    _head_ptr = nullptr;
    _CopyList(copyThis._head_ptr,_head_ptr);
}

template<typename T>
List<T>& List<T> :: operator =(const List<T>& RHS)
{
    if ( this == &RHS ){
        return *this;
    }
    //clear is in copylist
    _CopyList(RHS._head_ptr,_head_ptr);
    return *this;
}

template<typename T>
List<T> :: ~List()
{
    _ClearList(_head_ptr);
}

//--------------------------------------------

template<typename T>
typename List<T> :: Iterator List<T> :: NextNode(Iterator iMarker)
{
    return ++iMarker;
  //  return Iterator(_NextNode(_head_ptr,iMarker._ptr));
}

template<typename T>
typename List<T> :: Iterator List<T> :: search (const T& item)
{
    return Iterator(_search(_head_ptr,item));
}

template<typename T>
typename List<T> :: Iterator List<T> :: Insert_After(List<T> :: Iterator
                                                     iMarker, const T& item)
{
    return Iterator(_insert_after(_head_ptr,iMarker._ptr,item));
}

template<typename T>
typename List<T> ::Iterator List<T> :: Insert_Head(const T& item)
{
    return Iterator(_insert_head(_head_ptr,item));
}

template<typename T>
T List<T> :: Remove_Head()
{
    return _remove_head(_head_ptr);
}

template<typename T>
bool List<T> :: empty()
{
    return _empty(_head_ptr);
}

template<typename T>
bool List<T> :: is_descending() const
{
    if ( !_order ){
        return true;
    }
    return false;
}

template<typename T>
void List<T> :: clear()
{
    _ClearList(_head_ptr);
}

template<typename T>
T List<T> :: Delete(Iterator iMarker)
{
    return _delete(_head_ptr,iMarker._ptr);
}                     //the type of the stuff that returns is not node<T>

template<typename T>
const T& List<T> :: operator[](const int index) const//const version of the operator [ ]
{
    return At(_head_ptr,index);
}

template<typename T>
T& List<T> :: operator[](int index)       //return the item at index
{
    return At(_head_ptr,index);
}

template<typename T>
typename List<T> :: Iterator List<T> :: Begin() const
//return the head of the list
{
    return Iterator(_head_ptr);
}

template <typename T>
typename List<T> :: Iterator List<T>::End() const
//return the tail of the list
{
    return Iterator(_LastNode(_head_ptr));
}

template<typename T>
typename List<T> :: Iterator List<T>::Previous(Iterator iMarker)
//get the previous node to iMarker
{
    return Iterator(_PreviousNode(_head_ptr,iMarker._ptr));
}

template <class U>
ostream& operator<<(ostream& outs, const List<U>& l){
   l.Print();
   return outs;
}

template<typename T>
void List<T> :: Print() const            //print the list
{
    _print_list(_head_ptr);
}


#endif // LIST_ITERATOR_H
