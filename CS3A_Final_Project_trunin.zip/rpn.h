#ifndef RPN_H
#define RPN_H

#include <vector>
#include <SFML/Graphics.hpp>
#include "shunting_yard.h"
#include <cmath>
#include "iomanip"
#include "number.h"
#include "token.h"

using namespace std;

class Rpn
{
public:
    Rpn(Queue<Token*> postfix);
    double Evaluate(double xpos);
private:
    Queue<Token*> _post_fix;
};

#endif // RPN_H
