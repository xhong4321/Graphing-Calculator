#ifndef LPAREN_H
#define LPAREN_H

#include <iostream>
#include "token.h"

using namespace std;

class LParen : public Token
{
public:
    LParen();
    LParen(string lp);
    virtual int type0f();
    virtual void print();
private:
    string _lp;
};

#endif // LPAREN_H
