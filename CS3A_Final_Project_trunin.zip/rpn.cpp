#include "rpn.h"

Rpn::Rpn(Queue<Token*> postfix)
{
    _post_fix = postfix;
    cout << "rpn: "<<endl;
    _post_fix.front()->print();
    cout <<endl;
    _post_fix.back()->print();
    cout << endl;
}

double Rpn :: Evaluate(double xpos)
{
    double ypos = 0;
    Stack<Token*> postfix_temp;
    while ( !_post_fix.Empty() ) {
        Token* i = _post_fix.pop();
        cout << "inside rpn: " ;
        i->print();
        cout <<endl;
        if ( i->type0f() == NUMBER ){
            postfix_temp.push(i);
        }
        else if ( i->type0f() == VARIABLE ) {
            postfix_temp.push(new Number(xpos));
        }
        else if ( i->type0f() == OPERATOR ) {

            if( i->char_num() == 42 ){         //multiplication
                Token* j = postfix_temp.pop();
                Token* k = postfix_temp.pop();
                double result = j->actual_number() * k->actual_number();
                postfix_temp.push(new Number(result));
            }
            else if ( i->char_num() == 43 ) {  //addititon
                Token* j = postfix_temp.pop();
                Token* k = postfix_temp.pop();
                double result = j->actual_number() + k->actual_number();
                postfix_temp.push(new Number(result));
            }
            else if ( i->char_num() == 45 ) {  //subtraction
                Token* j = postfix_temp.pop();
                Token* k = postfix_temp.pop();
                double result = k->actual_number() - j->actual_number();
                postfix_temp.push(new Number(result));
            }
            else if ( i->char_num() == 47 ) {  //division
                Token* j = postfix_temp.pop();
                Token* k = postfix_temp.pop();
                double result = k->actual_number() / j->actual_number();
                postfix_temp.push(new Number(result));
            }
            else if ( i->char_num() == 94 ) {  //power
                Token* j = postfix_temp.pop();
                Token* k = postfix_temp.pop();
                double result = pow(k->actual_number(),j->actual_number());
                postfix_temp.push(new Number(result));
            }
            else if ( i->char_num() == 115 ) {  //sin
                Token* j = postfix_temp.pop();
                double num = j->actual_number();
                double result = sin(num);
                postfix_temp.push(new Number(result));
            }
            else if ( i->char_num() == 99 ) {  //cos
                Token* j = postfix_temp.pop();
                double num = j->actual_number();
                double result = cos(num);
                postfix_temp.push(new Number(result));
            }
            else if ( i->char_num() == 116 ) {  //tan
                Token* j = postfix_temp.pop();
                double num = j->actual_number();
                double result = tan(num);
                postfix_temp.push(new Number(result));
            }
            else if ( i->char_num() == 110 ) {  //ln
                Token* j = postfix_temp.pop();
                double num = j->actual_number();
                double result = log(num);
                postfix_temp.push(new Number(result));
            }
            else if ( i->char_num() == 111 ) {  //log
                Token* j = postfix_temp.pop();
                double num = j->actual_number();
                double result = log10(num);
                postfix_temp.push(new Number(result));
            }
            else if ( i->char_num() == 120 ) {  //exp
                Token* j = postfix_temp.pop();
                double num = j->actual_number();
                double result = exp(num);
                postfix_temp.push(new Number(result));
            }
        }
    }
    ypos = postfix_temp.pop()->actual_number();
    return ypos;
}
