#ifndef VARIABLE_H
#define VARIABLE_H


#include <iostream>
#include "token.h"

using namespace std;

class Variable : public Token
{
public:
    Variable();
    Variable( string var );

    virtual int type0f();
    virtual void print();
    virtual int char_num();
private:
    string _var;
};

#endif // VARIABLE_H
