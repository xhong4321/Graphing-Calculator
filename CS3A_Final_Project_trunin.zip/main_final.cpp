/*
 * Author: Xiangyu Hong
 * Project: Final Project: Graphing Calculator
 * Purpose: The purpose of this program is to create a sfml project and
 * geberate a graphing calculator which can let the user to input equations;
 * then, it can draw the graph for the user. In addititon, the user can also
 * zoom, pan, view history, save history, and check help screen.
 * Notes: I tested this project with a lot of equations.
*/

#include <iostream>
#include "animate.h"
using namespace std;

int main()
{

    animate game;
    cout << endl << "=================Here it starts================" << endl;
    game.run();
    cout<<endl<<endl<<"------ MAIN EXITING --------------------------"<<endl;
    return 0;
}

