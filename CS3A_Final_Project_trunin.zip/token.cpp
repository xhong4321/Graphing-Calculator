#include "token.h"

Token::Token()
{
    //blank
}

int Token :: type0f()
{
    //blank
}

int Token :: Prec()
{
    //blank
}

void Token :: print()
{
    //blank
}

int Token :: char_num()
{
    //blank
}

double Token :: actual_number()
{
    //blank
}
