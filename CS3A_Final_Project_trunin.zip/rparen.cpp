#include "rparen.h"

RParen::RParen()
{
    //blank
}

RParen :: RParen(string rp): _rp(rp)
{
    //blank
}

int RParen :: type0f()
{
    return RPAREN;
}

void RParen :: print()
{
    cout << _rp << " ";
}
