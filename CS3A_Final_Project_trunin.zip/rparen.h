#ifndef RPAREN_H
#define RPAREN_H


#include <iostream>
#include "token.h"

using namespace std;

class RParen : public Token
{
public:
    RParen();
    RParen(string rp);
    virtual int type0f();
    virtual void print();
private:
    string _rp;
};

#endif // RPAREN_H
