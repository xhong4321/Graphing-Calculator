#include "animate.h"
#include "constants.h"
#include <iostream>
#include "system.h"

using namespace std;

animate::animate(): _info(new Graph_info), system(_info), sidebar(WORK_PANEL, SIDE_BAR)
{
    read_from_file();
    set_info();
    cout<<"animate CTOR: TOP"<<endl;
    window.create(sf::VideoMode(SCREEN_WIDTH, SCREEN_HEIGHT), "Jerry's Graphing Calculator");
    //VideoMode class has functions to detect screen size etc.
    //RenderWindow constructor has a third argumnet to set style
    //of the window: resize, fullscreen etc.

    //System will be implemented to manage a vector of objects to be animated.
    //  at that point, the constructor of the System class will take a vector
    //  of objects created by the animate object.
    //  animate will
   // system = System();
    window.setFramerateLimit(60);

    //background:
    BackGround.setSize(sf::Vector2f(SCREEN_WIDTH,SCREEN_HEIGHT));
    BackGround.move(sf::Vector2f(0,0));
    BackGround.setFillColor(sf::Color(253,245,230));

    //helpkey:
    HelpKey.setSize(sf::Vector2f(50,75));
    HelpKey.move(sf::Vector2f(1045,10));
    HelpKey.setFillColor(sf::Color(64,224,208));
    HelpKey.setOutlineColor(sf::Color(128,128,128));
    HelpKey.setOutlineThickness(1);

    mouseIn = true;

    mousePoint = sf::CircleShape();
    mousePoint.setRadius(5.0);
    mousePoint.setFillColor(sf::Color::Red);

    cout<<"Geme CTOR. preparing to load the font."<<endl;
    //--- FONT ----------
    //font file must be in the "working directory:
    //      debug folder
    //Make sure working directory is where it should be and not
    //  inside the app file:
    //  Project->RUN->Working Folder
    //
    //font must be a member of the class.
    //  Will not work with a local declaration
    if (!font.loadFromFile("../arial.ttf")){
        cout<<"animate() CTOR: Font failed to load"<<endl;
        cin.get();
        exit(-1);
    }

    //input box
    inputBox.setSize(sf::Vector2f(1000,100));
    inputBox.move(sf::Vector2f(10,10));
    inputBox.setFillColor(sf::Color(229,255,204));

    //Help Box:
    HelpBox.setSize(sf::Vector2f(500,310));
    HelpBox.move(sf::Vector2f(20,30));
    HelpBox.setFillColor(sf::Color::Black);
    HelpBox.setOutlineColor(sf::Color::Yellow);
    HelpBox.setOutlineThickness(3);

    //Inputting:
    function_input_text.setFont(font);

    //help:
    HelpSign.setFont(font);
    HelpSign.setString("?");
    HelpSign.setCharacterSize(40);
    HelpSign.setStyle(sf::Text::Bold);
    HelpSign.setFillColor(sf::Color::Black);
    HelpSign.setPosition(sf::Vector2f(1058,22));

    //set up the sentences in the help box:
    set_help_box();

    myTextLabel = sf::Text("Initial String for myTextLabel", font);
    myTextLabel.setCharacterSize(20);
    myTextLabel.setStyle(sf::Text::Bold);
    myTextLabel.setColor(sf::Color::Green);
    myTextLabel.setPosition(sf::Vector2f(10,
                         SCREEN_HEIGHT-myTextLabel.getLocalBounds().height-5));

    cout<<"animate instantiated successfully."<<endl;
}

void animate::Draw(){
    window.draw(BackGround);

    //Look at the data and based on the data, draw shapes on window object.
    system.Draw(window);
//    if (mouseIn){
//        window.draw(mousePoint);  I don't want to show the mouse point
//    }

    window.draw(HelpKey);
    sidebar.draw(window);

    //- - - - - - - - - - - - - - - - - - -
//getPosition() gives you screen coords, getPosition(window) gives you window
   // coords
    //cout<<"mosue pos: "<<sf::Mouse::getPosition(window).x<<", "<<sf::Mouse::
            //getPosition(window).y<<endl;
    //- - - - - - - - - - - - - - - - - - -

    //drawing Test: . . . . . . . . . . . .
    //This is how you draw text:)
    window.draw(myTextLabel);
    window.draw(HelpSign);

    if (mouseIn){
       // mousePoint red dot:
        mousePoint.setPosition(sf::Mouse::getPosition(window).x-5,
                               sf::Mouse::getPosition(window).y-5);

     //   mouse location text for sidebar:  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        sidebar[SB_MOUSE_POSITION] = mouse_pos_string(window);
        //I choose to not include this one

    }
    //When the user inputs, show these two:
    if( is_input ){
        window.draw(inputBox);
        window.draw(function_input_text);
    }

    //where we draw the help box and its content:
    if( open_help ){
        window.draw(HelpBox);
        window.draw(pan_UD);
        window.draw(pan_LR);
        window.draw(zoom_in);
        window.draw(zoom_out);
        window.draw(history_eqn);
        window.draw(save_history);
        window.draw(reset_graph);
        window.draw(input_eqn);
        window.draw(help_screen);
    }

    //. . . . . . . . . . . . . . . . . . .
}

void animate::update(){
    //cause changes to the data for the next frame

    //Inputting Equation:
    function_input_text.setCharacterSize(30);
    function_input_text.setStyle(sf::Text::Bold);
    function_input_text.setFillColor(sf::Color::Black);
    function_input_text.setPosition(sf::Vector2f(40,37));

    //Domain:
    sidebar[SB_DOMAIN] = "Domain:";
    sidebar[SB_DOMAIN_VALUE] = "("+to_string(_info->_domain.x)+","+to_string(_info->_domain.y)+")";

    //Histiry on the sidebar:
    int num = SB_FUNCTION_SIDEBAR;
    int count = 0;
    if( !function_list.empty() ){
        Stack<string> temp = function_list;
        while(!temp.empty() && (count < MAX_HISTORY))
        {
            sidebar[num]=temp.front();
            temp.pop();
            num++;
            count++;
        }
    }

    system.Step(command,_info);  //I'm not changing anything untill now
    //I might make some changes when I update my "process event", for example,
    //I might shrink the domain when I press "enter", expand the domain when I
  //press shift + enter, pan left or pan right when I press left or right arrow

    command = 0;

}

void animate::render(){
       window.clear();
       Draw();
       window.display();
}



void animate::processEvents()
{
   sf::Event event;
   float mouseX, mouseY;
   while (window.pollEvent(event))//or waitEvent
       {
       // check the type of the event...
           switch (event.type)
           {
           // window closed
           case sf::Event::Closed:
               window.close();
               break;
           case sf::Event::TextEntered:
               if( is_input ){
                   if( event.text.unicode < 128 ){
                       if ( ( event.text.unicode == UNICODE_DELETE ) &&
                            //Delete key
                            ( function_input.length() > 0 ) ){
                           function_input.pop_back();
                       }
                       else {
                      function_input += static_cast<char>(event.text.unicode);
                       }
                       function_input_text.setString(function_input);
                   }
               }
               break;
           // key pressed
           case sf::Event::KeyPressed:
               switch(event.key.code){
               case sf::Keyboard::F:
                   sidebar[SB_KEY_PRESSED] = "Inputting Function: F";
                   function_input = "";  //initialization
                   is_input = true;
                   function_input_text.setString("f(x)=");
                   window.pollEvent(event);  //not sure what it is for
                   break;
               case sf::Keyboard::R:
                   sidebar[SB_KEY_PRESSED] = "Reset: R";
                   command = CMD_RESET;
                   changed = true;
                   break;
               case sf::Keyboard::Left:
                   sidebar[SB_KEY_PRESSED] = "Pan Left: Left Arrow";
                   command = CMD_PAN_LEFT;
                   changed = true;
                   break;
               case sf::Keyboard::Right:
                   sidebar[SB_KEY_PRESSED] = "Pan Right: Right Arrow";
                   command = CMD_PAN_RIGHT;
                   changed = true;
                   break;
               case sf::Keyboard::Up:
                   sidebar[SB_KEY_PRESSED] = "Pan Up: Up Arrow";
                   command = CMD_PAN_UP;
                   changed = true;
                   break;
               case sf::Keyboard::Down:
                   sidebar[SB_KEY_PRESSED] = "Pan Down: Down Arrow";
                   command = CMD_PAN_DOWN;
                   changed = true;
                   break;
               case sf::Keyboard::Q:
                   sidebar[SB_KEY_PRESSED] = "History Saved: Q";
                   save_to_file(function_list);
                   break;
               case sf::Keyboard::W:
                   sidebar[SB_KEY_PRESSED] = "Help Screen Closed: W";
                   open_help = false;
                   break;
               case sf::Keyboard::Escape:
                   sidebar[SB_KEY_PRESSED] = "ESC: EXIT";
                   window.close();
                break;
               case sf::Keyboard::Enter:  // Zoom in, Good
                   if( is_input ){
                       sidebar[SB_KEY_PRESSED] = "Function Input End";
                       is_input = false;
                       _info->_equation = function_input;  //for infix later
                       function_list.push(_info->_equation);
                       command = CMD_NEW_EQUATION;
                       function_input = "";  //make it back to default
                   }
                   else {
                       sidebar[SB_KEY_PRESSED] = "Zoom In: Enter";
                       command = CMD_ZOOM_IN;
                   }
                   changed = true;
                   break;
               case sf::Keyboard::RShift:  //Zoom out, Good
                   sidebar[SB_KEY_PRESSED] = "Zoom Out: Right Shift";
                   command = CMD_ZOOM_OUT;
                   changed = true;
                   break;
               }

               break;
           case sf::Event::MouseEntered:
               mouseIn = true;
               break;

           case sf::Event::MouseLeft:
               mouseIn = false;
               break;

           case sf::Event::MouseMoved:
                mouseX = event.mouseMove.x;
                mouseY = event.mouseMove.y;
                //Do something with it if you need to...
               break;
           case sf::Event::MouseButtonReleased:
                   if (event.mouseButton.button == sf::Mouse::Right)
                   {
                       sidebar[SB_MOUSE_LOCATE] = "RIGHT CLICK " +
                               mouse_pos_string(window);
//                       int x = sf::Mouse::getPosition(window).x;
//                       int y = sf::Mouse::getPosition(window).y;
//                       if ( ( y >= 0 && y <=SCREEN_HEIGHT ) &&
//                            //there two numbers are THE limit of box
//                      ( x >= 0 && x < SCREEN_WIDTH_WITHOUT_SBAR ) ){
//                           float zoom_in = 0.5;
//                          // float x_n = x/_info->_orgin.x;
//                         //  float y_n = y/_info->_orgin.y;
//                           float x_left = x;
//                           float x_right = SCREEN_WIDTH_WITHOUT_SBAR - x;
//                           if ( x_left > x_right ){
//                               _info->_domain.y *= ((x_right * zoom_in)/
                 //      _info->_scale.x)/_info->_domain.y;
//                               if ( _info->_domain.x < 0 )
//                               _info->_domain.x += ((x_left * zoom_in)/
                 //      _info->_scale.x)/(-1*_info->_domain.x);
//                               else {
//                                   _info->_domain.x += ((x_left * zoom_in)/
                  //     _info->_scale.x)/(_info->_domain.x);
//                               }
//                           }
//                           else {
//                               _info->_domain.x *= zoom_in;
//                               _info->_domain.y *= (zoom_in/x_right)*x_left;
//                           }
//                           _info->_scale.x = _info->_window_dimemsions.x/
//                                   (_info->_domain.y-_info->_domain.x);
//                           float y_up = y;
//                           float y_down = SCREEN_HEIGHT - y;
//                           if ( y_up > y_down ){  //pan up
//                               _info->_orgin.y -= (
                       //_info->_window_dimemsions.y/
//                               (_info->_range.y-_info->_range.x))*zoom_in;
//                           }
//                           else {  //pan down
//                               _info->_orgin.y += (
                     //  _info->_window_dimemsions.y/
//                                 (_info->_range.y-_info->_range.x))*zoom_in;
//                           }
//                       }
//                       changed = true;
                   }
                   else{
                       sidebar[SB_MOUSE_LOCATE] = "LEFT CLICK " +
                               mouse_pos_string(window);
                       int x = sf::Mouse::getPosition(window).x;
                       int y = sf::Mouse::getPosition(window).y;
                       if ( (y >= HISTORY_EQN_H && y <= HISTORY_EQN_H_BUTTON)&&
                            //there two numbers are height of box of history
                      ( x > SCREEN_WIDTH_WITHOUT_SBAR && x < SCREEN_WIDTH ) ){
                           int number = (y-HISTORY_EQN_H) / 37; //37 is scalar
                           Stack<string> f = function_list;
                           while ( number > 0 ) {
                               f.pop();  //work throuh to find the one that
                               number--;  //I click on
                           }
                           _info->_equation = f.front();
                           //set it to the info.equation
                           command = CMD_NEW_EQUATION;
                       }

                       else if( ( y > 0  && y <=75 ) &&
                              ( x>= 1045 && x < SCREEN_WIDTH_WITHOUT_SBAR ) ) {
                           open_help = true;
                           //Here the user opens the "help screen"
                       }
                       changed = true;
                   }

                   break;

               default:
                   break;
           }
       }
}

void animate::run()
{
   int count = 0;
   while (window.isOpen())
   {
       processEvents();
       if ( count == 0 ){
           changed = true;
           update();
           changed = false;
       }
       else {
           if ( changed ){
               update();
               changed = false;
           }
       }
       render();//clear/draw/display
       count++;
   }
   cout<<endl<<"-------ANIMATE MAIN LOOP EXITING ------------"<<endl;
}

string mouse_pos_string(sf::RenderWindow& window){
    return "(" +
            to_string(sf::Mouse::getPosition(window).x) +
            ", " +
            to_string(sf::Mouse::getPosition(window).y) +
            ")";
}

void animate :: set_info()
{
   // _info->_equation = "";
    _info->_window_dimemsions = sf::Vector2f(SCREEN_WIDTH_WITHOUT_SBAR,
                                             SCREEN_HEIGHT);
    _info->_domain = sf::Vector2f(-5,5);
    _info->_range = sf::Vector2f(-3.5,3.5);
    _info->_points = POINTS;
    float xpos = SCREEN_WIDTH_WITHOUT_SBAR / 2;
    float ypos = SCREEN_HEIGHT /2;
    _info->_orgin = sf::Vector2f(xpos,ypos);
    _info->_scale = sf::Vector2f(_info->_window_dimemsions.x/(
                                     (_info->_domain.y)-(_info->_domain.x)),0);
    //I can assess it right now
}

void animate :: read_from_file()
{
    ifstream inStream;
    inStream.open("functions.txt");
    if ( inStream.fail() ){
        cout << "Input file opening failed.\n";
        exit(1);
    }
    //because we switch the order, we read in the latest equation at the en
    string equation;
    getline(inStream,equation);
    while ( !inStream.eof() ) {
        function_list.push(equation);
        getline(inStream,equation);
    }
    _info->_equation =function_list.front();  //draw the current equation
    inStream.close();
}

void animate :: save_to_file(Stack<string> functionListS)
{
    ofstream outStream;
    outStream.open("functions.txt");
    if ( outStream.fail() ){
        cout << "Output file opening failed.\n";
        exit(1);
    }
    //Convert the order here using vector and stack
    vector<string> f_v;
    Stack<string> f = functionListS;
    int count = 1;
    string i = f.pop();
    while ( (!f.empty()) && (count < MAX_HISTORY) ) {
        f_v.push_back(i);
        count++;
        i = f.pop();
    }
    //make sure to drop the whitespace
    f_v.push_back(i);
    while ( !f_v.empty() ) {
        outStream << f_v.back() <<endl;
        f_v.pop_back();
    }
    outStream.close();
}

void animate :: set_help_box()
{
    //This is all the content on the help box:

    pan_UD.setFont(font);
    pan_UD.setString("Press Up/Down Arrow to Pan Up/Down");
    pan_UD.setCharacterSize(20);
    pan_UD.setStyle(sf::Text::Bold);
    pan_UD.setColor(sf::Color(255,0,0));
    pan_UD.setPosition(sf::Vector2f(25,170));


    pan_LR.setFont(font);
    pan_LR.setString("Press Left/Right Arrow to Pan Left/Right");
    pan_LR.setCharacterSize(20);
    pan_LR.setStyle(sf::Text::Bold);
    pan_LR.setColor(sf::Color(255,0,0));
    pan_LR.setPosition(sf::Vector2f(25,140));

    zoom_in.setFont(font);
    zoom_in.setString("Press Enter to Draw Graph / Zoom in");
    zoom_in.setCharacterSize(20);
    zoom_in.setStyle(sf::Text::Bold);
    zoom_in.setColor(sf::Color(255,0,0));
    zoom_in.setPosition(sf::Vector2f(25,80));

    zoom_out.setFont(font);
    zoom_out.setString("Press Right Shift to Zoom Out");
    zoom_out.setCharacterSize(20);
    zoom_out.setStyle(sf::Text::Bold);
    zoom_out.setColor(sf::Color(255,0,0));
    zoom_out.setPosition(sf::Vector2f(25,110));

    history_eqn.setFont(font);
    history_eqn.setString("Left Click the Equation on the Sidebar to Draw it");
    history_eqn.setCharacterSize(20);
    history_eqn.setStyle(sf::Text::Bold);
    history_eqn.setColor(sf::Color(255,0,0));
    history_eqn.setPosition(sf::Vector2f(25,230));

    save_history.setFont(font);
    save_history.setString("Press [Q] to Save the Equations on the Sidebar");
    save_history.setCharacterSize(20);
    save_history.setStyle(sf::Text::Bold);
    save_history.setColor(sf::Color(255,0,0));
    save_history.setPosition(sf::Vector2f(25,260));

    reset_graph.setFont(font);
    reset_graph.setString("Press [R] to Reset the Graph");
    reset_graph.setCharacterSize(20);
    reset_graph.setStyle(sf::Text::Bold);
    reset_graph.setColor(sf::Color(255,0,0));
    reset_graph.setPosition(sf::Vector2f(25,200));

    input_eqn.setFont(font);
    input_eqn.setString("Press [F] to Input Equations");
    input_eqn.setCharacterSize(20);
    input_eqn.setStyle(sf::Text::Bold);
    input_eqn.setColor(sf::Color(255,0,0));
    input_eqn.setPosition(sf::Vector2f(25,50));

    help_screen.setFont(font);
    help_screen.setString("Press [W] to Close the Help Screen");
    help_screen.setCharacterSize(20);
    help_screen.setStyle(sf::Text::Bold);
    help_screen.setColor(sf::Color(255,0,0));
    help_screen.setPosition(sf::Vector2f(25,290));

}
