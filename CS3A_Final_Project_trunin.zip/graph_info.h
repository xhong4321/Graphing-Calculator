#ifndef GRAPH_INFO_H
#define GRAPH_INFO_H

#include <iostream>
#include <SFML/Graphics.hpp>
#include "constants.h"

using namespace std;

struct Graph_info{
    string _equation;
    sf::Vector2f _window_dimemsions;
    sf::Vector2f _domain;
    sf::Vector2f _range;
    sf::Vector2f _orgin;
    sf::Vector2f _scale;
    int _points;
};


#endif // GRAPH_INFO_H
