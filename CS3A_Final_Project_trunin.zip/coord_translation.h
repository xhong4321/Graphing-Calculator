#ifndef COORD_TRANSLATION_H
#define COORD_TRANSLATION_H

#include <iostream>
#include <vector>
#include <SFML/Graphics.hpp>
#include "graph_info.h"

using namespace std;

class Coord_translation
{
public:
    Coord_translation(Graph_info* info);
    sf::Vector2f translate(sf::Vector2f point);
private:
    Graph_info* _info;
};

#endif // COORD_TRANSLATION_H
