#ifndef GAME_H
#define GAME_H
#include <SFML/Graphics.hpp>
#include "system.h"
#include "sidebar.h"
#include "graph_info.h"
#include "SFML/Audio.hpp"
#include "string.h"
#include "../../../Desktop/CS3/!includes/my_stack/stack_file.h"
#include "fstream"
#include "vector"

class animate{
public:
    animate();
    void set_info();
    void run();
    void processEvents();
    void update();
    void render();
    void Draw();
    //==========Save and Read=======================
    void read_from_file();
    void save_to_file(Stack<string> functionListS);
    //==============================================
    void set_help_box();  //set up the help box content
private:
    Graph_info* _info;
    sf::RenderWindow window;
    sf::RectangleShape BackGround;      //change the color of back ground
    sf::RectangleShape HelpKey;
    sf::CircleShape mousePoint;         //The little red dot
    sf::RectangleShape inputBox;     //for inputting
    sf::RectangleShape HelpBox;
    System system;                      //container for all the animated objects
    int command;                        //command to send to system
    sf::Font font;                      //font to draw on main screen
    sf::Text myTextLabel;               //text to draw on main screen
    bool mouseIn;                       //mouse is in the screen
    Sidebar sidebar;                    //rectangular message sidebar
    bool is_input = false;    //whether the user is inputting
    bool open_help = false;
    string function_input;    //the input function
    sf::Text function_input_text;  //equation to draw on the window
    Stack<string> function_list;  //functions have to save in "save"
    sf::Text show_domain;        //show the domain on the sidebar
    sf::Text HelpSign;           //this is "?"
    bool changed = false;        //Control the update so that I'm not going
    sf::Text pan_UD;             //to call plot over and over again
    sf::Text pan_LR;
    sf::Text zoom_in;        //These are the sentences that I'm going to
    sf::Text zoom_out;      //mention in "helpbox"
    sf::Text history_eqn;
    sf::Text save_history;
    sf::Text reset_graph;
    sf::Text input_eqn;
    sf::Text help_screen;
};

string mouse_pos_string(sf::RenderWindow& window);

#endif // GAME_H
