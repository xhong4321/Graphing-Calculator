#ifndef Z_WORK_REPORT_H
#define Z_WORK_REPORT_H

/*
Features:

    -Not Implemented: None.

    -Implemented: The purpose of this program is to create a sfml project and
   geberate a graphing calculator which can let the user to input equations;
   then, it can draw the graph for the user. In addititon, the user can also
   zoom, pan, view history, save history, and check help screen. This project
   can draw polynomials, trig functions, log and natural log functions, and
   expontial equations.

    -Partly implemented: None.


Bugs     :  No bugs.


Reflections:
        I have a better understanding of how sfml works. I have a better
        understanding of how to use sfml to get some tasks done. For example,
        I feel very confident to use Text and RectangleShapes to draw some
        stuffs on the window, or I feel confident using Keyboard and Mouse
        Click to do some tasks. It is indeed an awesome project. And I love
        it because it gives me a lot of space to show how I understand this
        class and my ability to generate a project. This project is so
        wide open, and I think I will make it better later.
*/

#endif // Z_WORK_REPORT_H
