#ifndef CONSTANTS_H
#define CONSTANTS_H
const float SCREEN_WIDTH = 1400;
const float SCREEN_HEIGHT = 800;
const float WORK_PANEL = SCREEN_WIDTH*4/5;
const float SIDE_BAR = SCREEN_WIDTH*1/5;
const float SCREEN_WIDTH_WITHOUT_SBAR = 1400 - SIDE_BAR;

const int SB_DOMAIN = 0;
const int SB_DOMAIN_VALUE = 1;
const int SB_MOUSE_LOCATE = 2;
const int SB_FUNCTION_SIDEBAR = 4;
const int SB_KEY_PRESSED = 19;
const int SB_MOUSE_POSITION = 20;

const int CMD_NEW_EQUATION = 0;
const int CMD_ZOOM_IN = 1;
const int CMD_ZOOM_OUT = 2;
const int CMD_PAN_LEFT = 3;
const int CMD_PAN_RIGHT = 4;
const int CMD_RESET = 5;
const int CMD_PAN_UP = 6;
const int CMD_PAN_DOWN = 7;

const int MAX_HISTORY = 10;
const int POINTS = 1000;
const int HISTORY_EQN_H_BUTTON = 528;
const int HISTORY_EQN_H = 158;
const int UNICODE_DELETE = 8;

#endif // CONSTANTS_H

//we have the stack, so we can calculate the number of the equation in oorder
//to get that equation then draw it(system......)
